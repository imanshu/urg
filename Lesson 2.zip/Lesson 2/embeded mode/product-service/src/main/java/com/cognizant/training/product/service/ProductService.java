package com.cognizant.training.product.service;

import com.cognizant.training.product.domain.Product;

public interface ProductService {

	public Product getById(Long id);
	
	public boolean saveProduct(Product product);
	
}
