package com.cognizant.training.product.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.training.product.domain.Product;
import com.cognizant.training.product.service.ProductService;

@Controller
public class ProductServiceController {
	private static Logger logger = LoggerFactory.getLogger(ProductServiceController.class);
	@Autowired 
	ProductService service;
	@RequestMapping(method=RequestMethod.GET,path="/product/{id}",produces = "application/json; charset=UTF-8")
	public @ResponseBody Product getProduct(@PathVariable("id") String id) {
		logger.info("incoming product Id is " + id);		
		return service.getById(Long.parseLong(id));
	}
}
