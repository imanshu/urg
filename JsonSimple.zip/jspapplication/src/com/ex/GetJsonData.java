package com.ex;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import jdk.nashorn.internal.parser.JSONParser;

public class GetJsonData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8080/content/b1.infinity.json";
		String stringjson = jsonGetRequest(url);
		
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		//System.out.println(jsonObject);
		//ArrayList<String> mylist = parseJsonObject(jsonObject);
		ArrayList<String> mylist1 = new ArrayList<String>();
	    //System.out.println(mylist1);
	    System.out.println(getFinalJson(jsonGetRequest(url)));

	}

	//method to get final result from url
	public static String getJsonFromPath(String pathurl) {
		String finalfulljson = getFinalJson(jsonGetRequest(pathurl));
		return finalfulljson;
		
	
  }
	// iterating getFullJson method over the full json if any path is there
	public static String getFinalJson(String stringjson) {
		stringjson = getFullJson(stringjson);
		System.out.println(stringjson);
	    ArrayList<String> childpathlist = arraylist(stringjson);
	    if (!childpathlist.isEmpty()) {
	    	 System.out.println(childpathlist);
		     stringjson = getFinalJson(stringjson);  
	    }
	return stringjson;
}
	// appendending jsoncontent in place of path
	public static String getFullJson(String stringjson) {
		//String stringjson = jsonGetRequest(url);
		//JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		ArrayList<String> pathlist = arraylist(stringjson);
		for (int i = 0; i < pathlist.size(); i++) {
	    	//System.out.println(mylist1.get(i));
	    	stringjson = stringjson.replaceAll('"'+pathlist.get(i)+'"',jsonGetRequest(pathlist.get(i)));
	    	
	    }
		return stringjson;
	}
	
	
	//return arraylist of all paths
	private static ArrayList<String> arraylist(String stringjson) {
		ArrayList<String> mylist1 = new ArrayList<String>();
		//String stringjson = jsonGetRequest(url);
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		ArrayList<String> finallist = new ArrayList<String>();
		parseJsonObject(jsonObject, finallist);
		return finallist;
	  }
	
	
	//return stringjson from url 
	public static String jsonGetRequest(String urlQueryString) {
	    String json = null;
	    try {
	      URL url = new URL(urlQueryString);
	      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	      connection.setDoOutput(true);
	      connection.setInstanceFollowRedirects(false);
	      connection.setRequestMethod("GET");
	      connection.setRequestProperty("Content-Type", "application/json");
	      connection.setRequestProperty("charset", "utf-8");
	      connection.connect();
	      InputStream inStream = connection.getInputStream();
	      json = streamToString(inStream); 
	    } catch (IOException ex) {
	      ex.printStackTrace();
	    }
	    return json;
	  }
	
	private static String streamToString(InputStream inputStream) {
	    @SuppressWarnings("resource")
		String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
	    return text;
	  }
	
	//appending keyvalues(in our case path) with their jsonvalues
	private static String appendedJson(String json, String keyvalue) {
	    String appendedjson = json.replaceAll(keyvalue,jsonGetRequest(keyvalue));
	    return appendedjson;
	  }
	
	//convert jsonstring to jsonobject
	public static JSONObject stringToJsonobject (String string) {
		JSONObject jsonObject = (JSONObject) JSONValue.parse(string);
		return jsonObject;
		
	}
	
	//parse json in keys and keyvalues fully (parsing childnodes also)
	public static void parseJsonObject(JSONObject jsonObj, ArrayList<String> mylist1 ) {
		//ArrayList<String> mylist1 = new ArrayList<String>();
		//System.out.println("List..."+mylist1);
	    for (Object key : jsonObj.keySet()) {
	        
	        String keyStr = (String)key;
	        Object keyvalue = jsonObj.get(keyStr);
	       
            String strkeyvalue = keyvalue.toString();
            
	        if (strkeyvalue.contains("localhost:8080") && !strkeyvalue.contains("jcr:primaryType")) {
	        	
	            mylist1.add(strkeyvalue);
	             //System.out.println(strkeyvalue);
	        
	           //System.out.println( keyStr + ":" + keyvalue);
	        }
	        //parsing keyvalue if it's a jsonobject
	        if (keyvalue instanceof JSONObject) {
	        	
	          
	        	//System.out.println("subnode");
	            parseJsonObject((JSONObject)keyvalue, mylist1);
	        }

	           
	    }
	    	    
	  }

}
