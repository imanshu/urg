package com.ex;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import jdk.nashorn.internal.parser.JSONParser;

public class GetFullContentJson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8080/content/data555/5/fileName";
		String stringjson = jsonGetRequest(url);
		System.out.println(stringjson);
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		//System.out.println(jsonObject);
		//ArrayList<String> mylist = parseJsonObject(jsonObject);
		ArrayList<String> mylist1 = new ArrayList<String>();
	    //parseJsonObject(jsonObject, mylist1);
	    //System.out.println(getFinalJson(url));
	}
	
	public static String getFinalJson(String path) {
			String stringjson = jsonGetRequest(path);
			stringjson = getFullJson(stringjson);
		    ArrayList<String> childpathlist = arraylist(stringjson);
		    if (!childpathlist.isEmpty()) {
		    	 System.out.println(childpathlist);
			     stringjson = getFullJson(stringjson);  
		    }
		return stringjson;
	}
	
	public static String getFullJson(String stringjson) {
		//String stringjson = jsonGetRequest(url);
		//JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		ArrayList<String> pathlist = arraylist(stringjson);
		for (int i = 0; i < pathlist.size(); i++) {
	    	//System.out.println(mylist1.get(i));
	    	stringjson = stringjson.replaceAll('"'+pathlist.get(i)+'"',jsonGetRequest(pathlist.get(i)));
	    	pathlist = arraylist(stringjson);
	    	//System.out.println(pathlist);
	    	System.out.println(stringjson);
	    	
	    }
		return stringjson;
	}
	
	
	//return arraylist of all paths
	private static ArrayList<String> arraylist(String stringjson) {
		ArrayList<String> mylist1 = new ArrayList<String>();
		//String stringjson = jsonGetRequest(url);
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		ArrayList<String> finallist = new ArrayList<String>();
		parseJsonObject(jsonObject, finallist);
		return finallist;
	  }
	
	
	//return stringjson from url 
	public static String jsonGetRequest(String urlQueryString) {
	    String json = null;
	    try {
	      URL url = new URL(urlQueryString);
	      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	      connection.setDoOutput(true);
	      connection.setInstanceFollowRedirects(false);
	      connection.setRequestMethod("GET");
	      connection.setRequestProperty("Content-Type", "application/html");
	      connection.setRequestProperty("charset", "utf-8");
	      connection.connect();
	      InputStream inStream = connection.getInputStream();
	      json = streamToString(inStream); 
	    } catch (IOException ex) {
	      ex.printStackTrace();
	    }
	    return json;
	  }
	
	private static String streamToString(InputStream inputStream) {
	    String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
	    return text;
	  }
	
	//convert jsonstring to jsonobject
	public static JSONObject stringToJsonobject (String string) {
		JSONObject jsonObject = (JSONObject) JSONValue.parse(string);
		return jsonObject;
		
	}
	
	//parse json in keys and keyvalues fully (parsing childnodes also)
	public static void parseJsonObject(JSONObject jsonObj, ArrayList<String> mylist1 ) {
		//ArrayList<String> mylist1 = new ArrayList<String>();
		//System.out.println("List..."+mylist1);
	    for (Object key : jsonObj.keySet()) {
	        
	        String keyStr = (String)key;
	        Object keyvalue = jsonObj.get(keyStr);
	       
            String strkeyvalue = keyvalue.toString();
            
	        if (strkeyvalue.contains("localhost:8080") && !strkeyvalue.contains("jcr:primaryType")) {
	        	
	            mylist1.add(strkeyvalue);
	            
	        }
	        //parsing keyvalue if it's a jsonobject
	        if (keyvalue instanceof JSONObject) {
	        	
	          
	            parseJsonObject((JSONObject)keyvalue, mylist1);
	        }

	           
	    }
	    	    
	  }

}

