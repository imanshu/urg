package com.ex;

import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeVisitor;

public class InsertTagBefore {
    public static void main(String... args) throws IOException {
    	
        final String html = "<div class=\"row RowLayout\"></div>";
        Document document = Jsoup.parse(html);
        Document doc = Jsoup.connect("http://localhost:8080/content/data555/5/fileName").get();
        String htmlString = doc.html();
        Element form = doc.select("form").first();
        //System.out.println(htmlString);
        Document bodylayout = Jsoup.connect("http://localhost:8080/content/htmllayouts/bodylayout/bodylayoutcontent").get();
        Document coloumnlayout = Jsoup.connect("http://localhost:8080/content/htmllayouts/coloumnlayout/coloumnlayoutcontent").get();
        Document rowlayout = Jsoup.connect("http://localhost:8080/content/htmllayouts/rowlayout/rowlayoutcontent").get();
        Document couponlayout = Jsoup.connect("http://localhost:8080/content/htmllayouts/couponlayout/couponlayoutcontent").get();
        
        Element div = rowlayout.select("div").first();
        //System.out.println(div);
        //div.prepend(bodylayout.toString());
        //div = div.select("div").first();
        //System.out.println(div);
        //div.prepend(rowlayout.toString());
        //System.out.println(div);
        //System.out.println(bodylayout);
        
       

       
        //System.out.println(mergedocument(bodylayout,(mergedocument(coloumnlayout,mergedocument(rowlayout,couponlayout)))));
        
        
        ArrayList<Document> list = new ArrayList<Document>();
        list.add(bodylayout);
        list.add(coloumnlayout);
        list.add(rowlayout);
        list.add(couponlayout);
   
        //System.out.println(list);
        
        System.out.println(mergefinaldocument(list,couponlayout));
        
    }
    public static Document mergedocument(Document doc1, Document doc2) {
    	Element div = doc1.select("div").first();
    	div.prepend(doc2.toString());
    	return doc1;
    } 
    
    public static Document mergefinaldocument(ArrayList<Document> list, Document doc2) {
    	for(int i = list.size()-2; i >= 0; i--) {
    		Document some = mergedocument(list.get(i),doc2);
    		doc2 = some;
    	}
    	
    	return doc2;
    } 
    public static String parseJsonObject(JSONObject jsonObj, String htmlstring ) {
		//ArrayList<String> mylist1 = new ArrayList<String>();
		//System.out.println("List..."+mylist1);
	    for (Object key : jsonObj.keySet()) {
	        
	        String keyStr = (String)key;
	        Object keyvalue = jsonObj.get(keyStr);
	       
            String strkeyvalue = keyvalue.toString();
            
	        if (htmlstring.contains(keyStr)) {
	        	Object keyvalue1 = jsonObj.get(keyStr);
	 	       
	            String strkeyvalue1 = keyvalue1.toString();
	        	htmlstring = htmlstring.replace("$"+keyStr,strkeyvalue1 );
	            //mylist1.add(strkeyvalue);
	             //System.out.println(strkeyvalue);
	        
	           //System.out.println( keyStr + ":" + keyvalue);
	        }
	        

	           
	    }
	    return htmlstring;
	    	    
	  }
}
