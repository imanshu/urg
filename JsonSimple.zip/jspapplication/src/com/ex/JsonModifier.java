package com.ex;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class JsonModifier {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://localhost:8080/content/jcp/en/templates.infinity.json";
		String stringjson = jsonGetRequest(url);
		
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		//System.out.println(jsonObject);
		//ArrayList<String> mylist = parseJsonObject(jsonObject);
		ArrayList<String> mylist1 = new ArrayList<String>();
	    parseJsonObject(jsonObject, mylist1);
	    System.out.println(mylist1);

	}

	//method to get final result from url
	public static String getJsonFromPath(String pathurl) {
		String finalfulljson = getFinalJson(jsonGetRequest(pathurl));
		return finalfulljson;
		
	
  }
	// iterating getFullJson method over the full json if any path is there
	public static String getFinalJson(String stringjson) {
		stringjson = getFullJson(stringjson);
		System.out.println(stringjson);
	    ArrayList<String> childpathlist = arraylist(stringjson);
	    if (!childpathlist.isEmpty()) {
	    	 System.out.println(childpathlist);
		     stringjson = getFinalJson(stringjson);  
	    }
	return stringjson;
}
	
	
	// appendending jsoncontent in place of path
	public static String getFullJson(String stringjson) {
		ArrayList<String> pathlist = arraylist(stringjson);
		for (int i = 0; i < pathlist.size(); i++) {
	    	//System.out.println(mylist1.get(i));
	    	stringjson = stringjson.replaceAll('"'+pathlist.get(i)+'"',jsonGetRequest("http://localhost:8080"+pathlist.get(i))+".infinity.json");
	    }
		return stringjson;
	}
	
	
	//return arraylist of all paths
	public static ArrayList<String> arraylist(String stringjson) {
		JSONObject jsonObject = (JSONObject) JSONValue.parse(stringjson);
		ArrayList<String> finallist = new ArrayList<String>();
		parseJsonObject(jsonObject, finallist);
		return finallist;
	  }
	
	
	//return stringjson from url 
	public static String jsonGetRequest(String urlQueryString) {
	    String json = null;
	    try {
	      URL url = new URL(urlQueryString);
	      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	      connection.setDoOutput(true);
	      connection.setInstanceFollowRedirects(false);
	      connection.setRequestMethod("GET");
	      connection.setRequestProperty("Content-Type", "application/json");
	      connection.setRequestProperty("charset", "utf-8");
	      connection.connect();
	      InputStream inStream = connection.getInputStream();
	      json = streamToString(inStream); 
	    } catch (IOException ex) {
	      ex.printStackTrace();
	    }
	    return json;
	  }
	
	private static String streamToString(InputStream inputStream) {
	    String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
	    return text;
	  }
	
	
	
	//appending keyvalues(in our case path) with their jsonvalues
	private static String appendedJson(String json, String keyvalue) {
	    String appendedjson = json.replaceAll(keyvalue,jsonGetRequest(keyvalue));
	    return appendedjson;
	  }
	
	
	
	//convert jsonstring to jsonobject
	public static JSONObject stringToJsonobject (String string) {
		JSONObject jsonObject = (JSONObject) JSONValue.parse(string);
		return jsonObject;
		
	}
	
	
	//parse json in keys and keyvalues fully (parsing childnodes also)
	public static void parseJsonObject(JSONObject jsonObj, ArrayList<String> pathlist ) {
		//ArrayList<String> mylist1 = new ArrayList<String>();
		System.out.println("List..."+pathlist);
	    for (Object key : jsonObj.keySet()) {
	        
	        String keyStr = (String)key;
	       if (keyStr.contains("templatePath")) {
	    	Object keyvalueobject1 = jsonObj.get(key);
            String strkeyvalue = keyvalueobject1.toString();
            pathlist.add(strkeyvalue);
	        System.out.println(key );
	        System.out.println(pathlist );
	       }
	        //parsing keyvalue if it's a jsonobject
	        if (jsonObj.get(key) instanceof JSONObject) {
	        	
	          
	        	System.out.println(jsonObj.get(key));
	            parseJsonObject((JSONObject)jsonObj.get(key), pathlist);
	        }

	           
	    }
	    	    
	  }
}
