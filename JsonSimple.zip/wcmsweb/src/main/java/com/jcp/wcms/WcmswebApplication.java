package com.jcp.wcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WcmswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(WcmswebApplication.class, args);
	}
}
