/*Template Controller*/
bccApp
		.controller(
				'PageTemplateController',
				function($scope, $state, $stateParams, NodeService, ContentService,$timeout) {
					$scope.currenModel = {};
					$scope.categoryModel = {};
					$scope.currentObject = $state.params.currentElement;
					$scope.currentModel = NodeService.currentModel;
					$scope.startCreation=false;

					$scope.defaultTemplateName="";
					
					var i = 0;
					var check = 0;
					var ContentItems="ContentItems";
					var existPaths=[];
					var existArrPaths=[];
					var newJson={};
					var newJsonStr="newJson";
					var addStr="]=v";
					var initArrStr="=[]";
					var tempArrStr="",arrStr="";
					$scope.firstCall=true;
					$scope.isEdit=false;
					$scope.initTree=[
					    {
					        "name": "CouponPageTemplate",
					        "type": "Page",
					        "path": "CouponPageTemplate",
					        "templatePath": "/content/jcp/en/templates/CouponPageTemplate",
					        "description": "Page template for Coupon Page",
					        "contentItemStartDate": "02/25/2017 12:00:00",
					        "contentItemEndDate": "03/25/2017 12:00:00",
				            "positionX": "0",
				            "positionY": "0",
					        "ContentItems": [
					          {
					            "name": "HeaderSection",
					            "type": "HeaderLayout",
					            "path": "CouponPageTemplate/HeaderSection",
					            "templatePath": "/content/jcp/en/templates/CouponPageTemplate/HeaderSection",
					            "contentItemStartDate": "02/25/2017 12:00:00",
					            "contentItemEndDate": "03/25/2017 12:00:00",
					            "positionX": "0",
					            "positionY": "0",
					            "ContentItems": []
					          },
					          {
					            "name": "BodySection",
					            "type": "BodyLayout",
					            "path": "CouponPageTemplate/BodySection",
					            "templatePath": "/content/jcp/en/fragments/BodyLayout/content",
					            "contentItemStartDate": "02/25/2017 12:00:00",
					            "contentItemEndDate": "03/25/2017 12:00:00",
					            "positionX": "0",
					            "positionY": "0",
					            "ContentItems": []
					          },
					          {
					            "name": "FooterSection",
					            "type": "FooterLayout",
					            "path": "CouponPageTemplate/FooterSection",
					            "templatePath": "/content/jcp/en/templates/CouponPageTemplate/FooterSection",
					            "contentItemStartDate": "02/25/2017 12:00:00",
					            "contentItemEndDate": "03/25/2017 12:00:00",
					            "positionX": "0",
					            "positionY": "0",
					            "ContentItems": []
					          }
					        ]
					      }
					    ];
					$scope.tree2 = $scope.initTree;
					/*parsing the data got from JCR*/
					var alterdata = function(data, str) {
						if($scope.firstCall)
							{
							existPaths=[];
							existArrPaths=[];
							newJson={};
							check=0;
							$scope.firstCall=false;
							tempArrStr="",arrStr="";
							}
					    /*initialize before each iteration on Obj*/
					    i = 0;
					    /*calculating the length of the Obj*/
					    var length = 0;
					    var objLength = Object.keys(data).length;

					    angular.forEach(data, function(v, g) {
					        if (angular.isObject(v) && (v[0]!=="mix:lockable")) {
					            /*After Entering first Obj*/
					            check = 1;

					            var arrPath = str + "/" + ContentItems;

					            str = str + "/" + ContentItems + "/" + i;

					            /*Traversed Paths without Content-Items in the path-name*/
					            existPaths.push(str);

					            console.log(str);
					            tempArrStr = str.split("/").join("][");
					            arrStr = tempArrStr.slice(1, tempArrStr.length);
					            var defArr = arrStr.slice(0, arrStr.length - 2);
					            /*creating a new ContentItem Arr before adding the data*/
					            if (existArrPaths.indexOf(arrPath) == -1) {
					                
					                var removeObjStr = defArr.slice(0, defArr.length - ContentItems.length - 2);
					                eval("delete " + newJsonStr + removeObjStr + "[g];");
					                eval(newJsonStr + defArr + initArrStr);
					                /*Traversed Paths withContent-Items in the path-name*/
					                existArrPaths.push(arrPath);
					            }
					            /*inserting the value to ContentItem Array Created*/
					            eval(newJsonStr + arrStr + addStr);
					            console.log(newJson);
					            alterdata(v, str);

					            if (existPaths.indexOf(str) != -1 && !noChildObj) {
					                /*if it enters the same path again*/
					                i = 0;
					                temp = str.split("/");
					                temp[temp.length - 1] = String(i);
					                str = temp.join("/");
					                noChildObj = false;
					            } else {
					                /*getting out from the inner loop so popping out the last child and entering new parent(so incremented) */
					                var temp = str.split("/");
					                temp.pop();
					                temp.pop();
					                var lastcount = str.slice(str.length - 1, str.length);
					                str = temp.join("/");
					                i = Number(lastcount) + 1;
					            }
					        } else {
					            if (check === 0) {
					                newJson[g] = v; /*first time setting the values of the PageTemplate Properties*/
					            }
					            length = length + 1;
					            if (length == objLength && arrStr!="") {
					                eval(newJsonStr + arrStr + "][" + ContentItems + "]=[]"); /*create a new Content-Item Array If its without Obj*/
					                console.log("This Obj has no Objects");
					                noChildObj = true;
					            }

					        }
					    });
					    data = [];
					    return newJson;
					};
					
					$scope.$on("startTemplate",function(evt,data){
						$scope.isEdit=true;
						$scope.startCreation=false;
						$scope.tree2=$scope.initTree;
						NodeService.currentModel=$scope.tree2[0];
						NodeService.isAuthor=true;
						$(".tree-node").removeClass("highlighted");
						$(".tree-node:first").addClass("highlighted");
						if($state.current.name!=="cloning.categories")
							{
							$state.go("cloning.categories", {});
							}
						else
							$scope.$broadcast("clickedMe", {data:NodeService.currentModel,isEdit:$scope.isEdit});
					});
					
					$scope.$on("fetchTemplate", function(evt, data) {
						ContentService.getTemplateData('templates', data).then(
								function(response) {
									$scope.firstCall=true;
									$scope.isEdit=true;
									var responseData =alterdata(response.data,"");
									console.log(responseData);
									NodeService.currentTemplateName=responseData.name;
									$scope.startCreation=true;
									$scope.tree2=[responseData];
									NodeService.currentModel=$scope.tree2[0];
									NodeService.isAuthor=false;
									$scope.treeStruct = {
											"ContentItems" : $scope.tree2
										};
								});
						$state.go("cloning", {});

					});

					
					
					
					
					
					
					$scope.submit = function(err) {
						console.log(err);

						/*Checking for any mandatory/Field level errors*/
						if (err.hasOwnProperty('required')
								|| err.hasOwnProperty('maxlength')
								|| err.dateInValid || err.timeInValid) {
							$("#myModal").modal();
						} else {
							/*setting of Json Details before sending to server*/
							var myJson = $scope.treeStruct;

							console.log(myJson);

							ContentService.saveData("templates", myJson).then(
									function(response) {
										var submitResponse = response;
										$scope.data = submitResponse;
										if (submitResponse.status == 200) {
											// $scope.getCouponDetails('coupon');
											$("#mySuccessModal").modal();
										}
									});

						}
					};

					
					
					$scope.checkStateParams = function() {
						$scope.categoryModel.name = $stateParams.name;
					};

					$scope.updateModel = function(scope) {
						$scope.name = scope.name || " ";
						$scope.ContentType = scope.type || " ";
						$scope.positionX = Number(scope.positionX);
						$scope.positionY = Number(scope.positionY);
					};
					$scope.removeData=function(scope)
					{
						$scope.highlightClass = "";
						
						var templatePath=scope.$parent.node.templatePath;
						scope.remove();
/*						ContentService.deleteTemplateData('Content', templatePath).then(
								function(response) {
									console.log(response.status);
									var currTemplate=$scope.tree2;
									NodeService.createVersionControl(currTemplate);
									
									
								});*/
						
						
					};
					$scope.remove = function(scope) {
						

						$scope.highlightClass = "";
						scope.remove();
					};

					$scope.toggle = function(scope) {
						$scope.highlightClass = "";
						scope.toggle();
					};
					$scope.showTitle = function(elem, current) {
						$(".tree-node").removeClass("highlighted");
						var attachHighlight = $(current.$element).find(
								".tree-node")[0];
						$(attachHighlight).addClass("highlighted");
						$scope.startCreation=false;
						$scope.currenModel = elem;
						NodeService.currentModel = elem;
						$scope.$broadcast("clickedMe", {data:elem,isEdit:$scope.isEdit});
						$scope.currentModel = elem;
						$state.params.currentElement = elem;
					
							$state.go("cloning.categories", {
								currentElement : elem
							});

							//$scope.$emit("clickedMe", {data:elem,isEdit:$scope.isEdit});
					
						//$state.go(elem.ref,{currentElement:elem});

						//$stateProvider.state(elem.ref,{});
						//elem.highlightClass="highlighted";
					};
					$scope.newSubItem = function(scope) {
						$scope.highlightClass = "";
						var nodeData = scope.$modelValue;
						nodeData.ContentItems.push({
							id : nodeData.id * 10
									+ nodeData.ContentItems.length,
							name : "Content-Slot-Default",
							ref : nodeData.ref || "",
							type : " ",
							hideBtn : true,
							positionX : 0,
							positionY : 0,
							ContentItems : []
						});
					};

					$scope.addCategoryType = function(value) {
						$scope.highlightClass = "";
						var nodeData = $scope.$parent.currenModel;
						NodeService.addContentItem(nodeData, value);

					};

					$scope.saveCategoryDetails = function(scope) {
						var textFields = $('form[name=categoryForm]').find(
								"input[type='text'],input[type='number']");
						var nodeData = scope.$parent.currenModel;
						NodeService.updateContentItem(nodeData, textFields);

					};

					$scope.addContentSlots = function(slotType, scope) {
						$scope.highlightClass = "";
						//$scope.showTitle(scope);
						var nodeData = scope.$parent.currenModel;
						nodeData.ContentItems.push({
							id : nodeData.id * 10
									+ nodeData.ContentItems.length,
							name : "Content-Slot-Default",
							ref : nodeData.ref || "",
							type : " ",
							hideBtn : true,
							positionX : 0,
							positionY : 0,
							ContentItems : []
						});

					};

					$scope.subTitles = [ {
						"PageTitle" : {
							'title' : 'New Component'
						}

						,
						"Categories" : {
							'title' : 'New Component'
						}
					} ];

					

					$scope.treeStruct = {
						"ContentItems" : $scope.tree2
					};
				});