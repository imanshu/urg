bccApp
.controller('ContentCtrl',  function ($scope,$state,$stateParams,NodeService,ContentService) {
	$scope.nonEditable=false;
	$scope.nonEditableFieldTypes=['Title','BodyLayout','Page','HeaderLayout','FooterLayout'];
	$scope.coupons=NodeService.coupons || [];
	$scope.filterJcr=NodeService.filterJcr;
	$scope.canContentTypeBeAdded=false;
	$scope.canContentBeAdded=false;
	$scope.servicePath="service path here";
	/*Daet&Time Picker Initial Configurations */
    $("#timepicker,#timepicker2").timepicker({});
    $('#datepicker_slot,#datepicker1_slot').datepicker({
    	clearBtn:true,
    	autoclose:true,
    	format: 'mm/dd/yyyy',
        todayBtn: true,
        startDate: new Date(),
        todayHighlight: true

    });
    	$scope.$on("clickedMe", function(evt,opt){ 
    		console.log(opt);
    		
		$scope.initialize(opt.data,opt.isEdit);
	
	});
	  $scope.initialize=function(data,isEdit)
	  {
			
		  data=data ? data:NodeService.currentModel;
		  if(data!==undefined && Object.keys(data).length!==0)
				{
			    $scope.name=data.name||" ";
				$scope.ContentType=data.type||" ";
				$scope.positionX=Number(data.positionX);
				$scope.positionY=Number(data.positionY);
				$scope.width=Number(data.width)||0;
				$scope.height=Number(data.height)||0;
				$scope.fromDate=data.contentItemStartDate.split(" ")[0] || " ";
				$scope.fromTime=data.contentItemStartDate.split(" ")[1] || " ";
				$scope.toDate=data.contentItemEndDate.split(" ")[0] || " ";
				$scope.toTime=data.contentItemEndDate.split(" ")[1] || " ";
				$scope.templatePath=data.templatePath || " ";
				$scope.serviceLink=data.serviceLink || " ";
				$scope.contentToAdd=data.associatedCoupon || " ";
				if($scope.nonEditableFieldTypes.indexOf($scope.ContentType)!==-1 && !NodeService.isAuthor)
					{
					$scope.nonEditable=true;
					}
				else
					$scope.nonEditable=false;
				
				if(data.type==="Content")
					{
					$scope.canContentTypeBeAdded=true;
					$scope.canContentBeAdded=false;
					$scope.coupons=NodeService.coupons || [];
					}
				else
					if(data.type!=="Page")
						{
						$scope.canContentTypeBeAdded=false;
						$scope.canContentBeAdded=true;
						}
					
				
				}
		  else
			  
			  {
			  $state.go("cloning",{});
			  }
			
		  
	  };
  
	  $scope.dateValid=function(value){
		  
		  
	  };
	  
	  $scope.addCategoryType=function(value){
			$scope.highlightClass="";
		    var nodeData = $scope.$parent.currenModel;
		    
		    var currTemplate=$scope.$parent.tree2;
		    NodeService.addContentItem(nodeData,value);
		    //NodeService.createVersionControl(currTemplate);
	  };
	  $scope.saveCategoryDetails=function(scope){
		  var textFields=$('form[name=categoryForm]').find("input[type='text'],input[type='number']");
		  var nodeData = scope.$parent.currenModel;
		  NodeService.updateContentItem(nodeData,textFields);
	  };
	  $scope.addContents=function(scope)
	  {
		  var nodeData = scope.$parent.currenModel;
		  var contentToAdd= scope.contentToAdd;
		  scope.$parent.serviceLink="http://localhost:8080/content/jcp/en/coupon/" + contentToAdd + ".json";
		  nodeData.serviceLink=scope.$parent.serviceLink;
		  ContentService.getData('coupon', contentToAdd).then(function(response){
				var contentFetched=response.data;
				 NodeService.addContentToSlot(nodeData,contentFetched);
				});
		  
	  }
	  
	
});