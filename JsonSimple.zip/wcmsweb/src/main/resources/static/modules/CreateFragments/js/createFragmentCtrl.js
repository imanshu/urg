bccApp.controller('createFragmentCtrl',function($scope,NodeService,ContentService){
	
	$scope.assetFilePath="/jcp/en/fragment/";
	
		
	$scope.submitFragment=function(form)
	{
		$scope.assetFilePath="/jcp/en/fragment/"+$scope.assetName;
		if($scope.codeSelect=="codeNotAvailable")
			{
			var templateContent=$scope.assetFilePath;
			}else
				{
				var templateContent=$scope.assetText;
				}
		var data={
				"assetName":$scope.assetName||" ",   
				"mimeType":"text/html",   
				"parentFolder":$scope.assetFilePath || " ",   
				"templateContent":templateContent || " "  
		};
		ContentService.saveData(data,"fragments").then(function(response){
			console.log(response);
		});
		console.log(data);
	};
	

});