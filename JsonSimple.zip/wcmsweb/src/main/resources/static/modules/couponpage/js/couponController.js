/*couponController */
bccApp.controller('couponController', ['$scope', '$http', '$timeout','ContentService', function($scope, $http, $timeout,ContentService) {
	
	/*Daet&Time Picker Initial Configurations */
    $("#timepicker,#timepicker2").timepicker({});
    $('#datepicker,#datepicker1').datepicker({
    	clearBtn:true,
    	autoclose:true,
    	format: 'mm/dd/yyyy',
        todayBtn: true,
        startDate: new Date(),
        todayHighlight: true

    });
$scope.viewJson=function(){
	console.log("I am here");
	 $scope.myJson = {
	            "couponName": $scope.couponName,
	            "couponStartDate": $scope.fromDate + " " + $scope.fromTime,
	            "couponEndDate": $scope.toDate + " " + $scope.toTime,
	            "categoryPage": $scope.categoryPage,
	            "Channel": $scope.Channel,
	            "Active": $scope.Active,
	            "offer1Name": $scope.offer1Name,
	            "offer1Description": $scope.offer1Description || " ",
	            "offer2Name": $scope.offer2Name || " ",
	            "offer2Description": $scope.offer2Description || " ",
	            "offer3Name": $scope.offer3Name || " ",
	            "offer3Description": $scope.offer3Description || " ",
	            "offer4Name": $scope.offer4Name || " ",
	            "offer4Description": $scope.offer4Description || " ",
	            "validName": $scope.validName || " ",
	            "shopTitle": $scope.shopTitle || " ",
	            "codeValue": $scope.codeValue || " ",
	            "codeSelect": $scope.codeSelect || " ",
	            "detailTitle": $scope.detailTitle,
	            "displayWithProduct": $scope.displayWithProduct,
	            "barCode1": $scope.barCode1 || " ",
	            "barCode2": $scope.barCode2 || " ",
	            "disclaimer": $scope.disclaimer || " ",
	            "couponShopUrl": " ",
	            "couponDetailURL": " "
	        };
	 console.log("I am ending here");
};
    

    $scope.Channel="InStore";
    $scope.Active="Yes";
    $scope.detailTitle="Get Details Only";
    $scope.displayWithProduct="No";
	$scope.$on("fetchCoupon", function(evt,data){
		ContentService.getData('coupon', data).then(function(response){
			var responseData=response.data;
			$scope.myJson=responseData;
			console.log(responseData);
        	$timeout(function() {
                angular.forEach(responseData, function(value, key) {
                    if (key == "couponStartDate") {
                        $scope.fromDate = value.split(" ")[0];
                        $scope.fromTime = value.split(" ")[1] + " " + value.split(" ")[2];
                    } else
                    if (key == "couponEndDate") {
                        $scope.toDate = value.split(" ")[0];
                        $scope.toTime = value.split(" ")[1] + " " + value.split(" ")[2];

                    } else {
                        $scope[key] = value;
                    }

                });
                $scope.$apply();
            }, 200);
		});

	});
	
    /*Validating the Date Fields*/
    $scope.dateValid = function() {
        var fromDate = new Date($scope.fromDate);
        var toDate = new Date($scope.toDate);
        if (toDate < fromDate) {
            $scope.bccForm.toDate.$error.dateInValid = true;
            $scope.bccForm.$error.dateInValid = true;
            $scope.bccForm.toTime.$error.timeInValid = false;
            $scope.bccForm.$error.timeInValid = false;
        } else if ($scope.fromDate === $scope.toDate) {
            $scope.bccForm.toDate.$error.dateInValid = false;
            $scope.bccForm.$error.dateInValid = false;
            $scope.timeValid();
        } else {

            $scope.bccForm.toDate.$error.dateInValid = false;
            $scope.bccForm.$error.dateInValid = false;
            $scope.bccForm.toTime.$error.timeInValid = false;
            $scope.bccForm.$error.timeInValid = false;

        }
    };
    
    /*Converting the TimeFields for Comparision*/
    $scope.changeToTimeComparision = function(time) {
        if (time.length > 1) {
            var periodOfTime = time[1];
            var timeParts = time[0].split(":");
            var hourPart = timeParts[0];
            if (hourPart == "12") {
                hourPart = "0";
                time[0] = timeParts.join(":");
            }

            if (periodOfTime == "PM") {
                timeParts[0] = String(Number(hourPart) + 12);
                time[0] = timeParts.join(":");
            }
            console.log(time);
            return time;
        } else {
            console.log(time);
            return time;
        }

    };
    
    /*Validating the Time Fields*/
    $scope.timeValid = function() {
        $scope.fromTime = ($scope.fromTime == "") ? fromTimeDefault : $scope.fromTime;
        $scope.toTime = ($scope.toTime == "") ? toTimeDefault : $scope.toTime;
        if ($scope.toDate != undefined && $scope.fromDate != undefined) {
            var toDateBefore = $scope.toDate;
            var fromDateBefore = $scope.fromDate;
            var toDate = new Date($scope.toDate);
            var fromDate = new Date($scope.fromDate);
            var toDateStr = toDate.toString();
            var fromDateStr = fromDate.toString();
            var toDateStrParts = toDate.toString().split(" ");
            var fromDateStrParts = fromDate.toString().split(" ");
            var toTimeLocal = $scope.changeToTimeComparision($scope.toTime.split(" "));
            var fromTimeLocal = $scope.changeToTimeComparision($scope.fromTime.split(" "));
            toDateStrParts[4] = toTimeLocal[0];
            fromDateStrParts[4] = fromTimeLocal[0];
            var toDate = new Date(toDateStrParts.join(" "));
            var fromDate = new Date(fromDateStrParts.join(" "));
            if (toDateBefore === fromDateBefore) {
                if (toDate < fromDate) {
                    $scope.bccForm.toTime.$error.timeInValid = true;
                    $scope.bccForm.$error.timeInValid = true;
                } else {
                    $scope.bccForm.toTime.$error.timeInValid = false;
                    $scope.bccForm.$error.timeInValid = false;
                }
            }
        }
    };
    
    /*Submitting the Form Fields*/
    $scope.submit = function(err) {
        console.log(err);
        
        /*Checking for any mandatory/Field level errors*/
        if (err.hasOwnProperty('required') || err.hasOwnProperty('maxlength') || err.dateInValid || err.timeInValid) {
            $("#myModal").modal();
        } 
        else
        {
        	 console.log($scope.myJson);
            
            ContentService.saveData("coupon",$scope.myJson).then(function(response){
            	var submitResponse=response;
                $scope.data = submitResponse;
                if (submitResponse.status == 200) {
                    $scope.getCouponDetails('coupon');
                    $("#mySuccessModal").modal();
                }
            });


        }
    };
    
    
	
	
}]);
