bccApp.config(function($stateProvider, $urlRouterProvider, $httpProvider) {

/*header configurations for cross-domain requests*/
    $httpProvider.defaults.headers.common = {};
    $httpProvider.defaults.headers.post = {};
    $httpProvider.defaults.headers.put = {};
    $httpProvider.defaults.headers.patch = {};



    /*url mappings using angular-ui for later enchancements*/
    $stateProvider
        .state('forms', {
            url: "/forms",
            templateUrl: "partials/forms.html"
        })
        .state('couponpage', {
            url: "/couponpage",
            controller:'couponController',
            templateUrl: "modules/couponpage/templates/couponpage.html"
        })
        .state('basic-example', {
            url: "/basic-example",
            controller:'BasicExampleCtrl',
            templateUrl: "pages/basic-example.html"
        })
        .state('createFragments', {
            url: "/createFragments",
            controller:'createFragmentCtrl',
            templateUrl: "modules/createFragments/templates/createFragments.html"
        })
        .state('cloning', {
            url: "/cloning",
            params: {
                portfolioId: "Hello World",
                currentElement:{}
              },
            controller:'PageTemplateController',
            templateUrl: "modules/pagetemplate/templates/contentTemplate.html"
        })
        .state('cloning.pageTitle', {
            url: "/pageTitle",
            controller:function($scope,$state,$stateParams){
            	$scope.checkForElem=$state.params.currentElement;
            	$scope.checkForElem = $stateParams.portfolioId;
            },
            templateUrl: "pages/pageTitle.html"
        })
        .state('cloning.categories', {
            url: "/categories",
            controller:'ContentCtrl',
            templateUrl: "modules/slotcreator/templates/categories.html",


        })
        .state('cloning.category', {
            url: "/category",
            controller:'PageTemplateController',
            templateUrl: "pages/category.html"
        })
        .state('cloning.coupons', {
            url: "/coupons",
            controller:'PageTemplateController',
            templateUrl: "pages/coupon.html"
        })
});