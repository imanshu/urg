/*application start*/
var bccApp = angular.module('bccApp', ['ui.router','ui.tree']);

