
/*FormController/AppController*/
bccApp.controller('formController', ['$scope', '$http', '$state', '$timeout','ContentService','NodeService' ,function($scope, $http, $state, $timeout,ContentService,NodeService) {
	/*setting default values for From & To times*/
	var fromTimeDefault = "12:00:00 AM";
    var toTimeDefault = "11:59:59 PM";
    $scope.fromTime = fromTimeDefault;
    $scope.toTime = toTimeDefault;
    
    
    $scope.startCouponPage=function(){
    	$("form[name='bccForm']").find('input').each(function(value,key){$(key).val(" ");});
    	$state.go("couponpage", {});
    };
    

    $scope.filterJcr=function(value)
    {
    	return value!=="jcr:primaryType" && value!=="jcr:mixinTypes";
    };
    
    /*fetching the Entire Coupon Details*/
    $scope.getCouponDetails = function(type) {
    	console.log("in");
    	ContentService.getCollection("coupon").then(function(response){
    		$scope.coupons=Object.keys(response.data);
    		NodeService.coupons=$scope.coupons;
    		console.log($scope.coupons);
    	});
    	
    };
    
    /*fetching the Entire Template Details*/
    $scope.getTemplateDetails = function(type,isRoute) {

    	ContentService.getCollection("templates").then(function(response){
    		$scope.templates=response.data;
    		var templatesBeforeFilterJCR=Object.keys(response.data);
    		var templatesAfterFilterJCR=templatesBeforeFilterJCR.filter($scope.filterJcr);
    		NodeService.templates=templatesAfterFilterJCR;

    	});

    	console.log($scope.templates);
    	if(isRoute)
		{
    	$state.go("cloning", {});
		}
    };
    
    $scope.filterJCR = function (item) { 
    	if(item.indexOf("jcr")===-1)
    		{
    		return true;
    		}
    	else
    		{
    		return false;
    		}
       
    };
    /*Editing a particular Coupon*/
    $scope.fetchCouponEdit = function(couponName) {
    	
        if (String(couponName).indexOf("COUPON") != -1) {
        	$scope.$broadcast("fetchCoupon",couponName);
        }

    };
    
    /*Editing a particular Coupon*/
    $scope.fetchTemplateEdit = function(templateName) {
    	
        if (String(templateName).indexOf("Template") != -1) {
        	NodeService.currentModel={};
        	$scope.$broadcast("fetchTemplate",templateName);
        }

    };
    /*Start a Template Page*/
    $scope.startTemplatePage=function(){
    	$scope.$broadcast("startTemplate");
    	$state.go("cloning.categories", {});
    }


}]);
