/*Node Service*/
bccApp.service('NodeService',function($timeout,$http){
	var self=this;
	this.treeValue={};
	this.currentModel={};
	this.templates=[];
	this.currentTemplateName="";
	this.coupons=[];
	this.isAuthor=false;
	
	
	this.filterJcr=function(value)
    {
    	return value!=="jcr:primaryType" && value!=="jcr:mixinTypes";
    };
	
	this.addContentItem=function(nodeData,value)
	{
	    nodeData.ContentItems.push({
	    	name: "New-Content",
	        type:value.layoutToAdd,
            path:nodeData.path+"/"+"New-Content",
            templatePath:"/content/jcp/en/fragments/"+value.layoutToAdd+"/content",
            contentItemStartDate:" ",
            contentItemEndDate:" ",
            positionX:0,
            positionY:0,
	        ContentItems: []
	    });
	};
	/*callback for changing the path-values*/
	this.updatePathDetails=function(nodeData){
		
		if(nodeData.ContentItems.length!=0){
		//var currentTemplatePath=nodeData.templatePath;
		var currentPath=nodeData.path;
		nodeData.ContentItems.forEach(
		function(obj,key){

		//obj.templatePath=currentTemplatePath+"/"+obj.name;
		obj.path=currentPath+"/"+obj.name;
		//console.log(obj.templatePath);
		if(obj.ContentItems.length!=0){
			self.updatePathDetails(obj);
		}
		else
		{
		//obj.templatePath=currentTemplatePath+"/"+obj.name;
		//obj.templatePath=currentTemplatePath+"/"+obj.name;
		obj.path=currentPath+"/"+obj.name;
		console.log(obj.templatePath);
		}

		});
			}
		
		};
		
	this.updateContentItem=function(nodeData,textFields)
	{
		  
		nodeData["contentItemStartDate"]=textFields[6].value+" "+textFields[7].value;
		nodeData["contentItemEndDate"]=textFields[8].value+" "+textFields[9].value;
		/*path setting*/
		var pathParts=nodeData["path"].split("/");
		//var templatePathParts=nodeData["templatePath"].split("/");
		pathParts[pathParts.length-1]=textFields[0].value;
		//templatePathParts[templatePathParts.length-1]=textFields[0].value;
		
		nodeData["path"]=pathParts.join("/");
		//nodeData["templatePath"]=templatePathParts.join("/");
		
		
		this.updatePathDetails(nodeData,this);
		

			
		
		
		textFields.each(function(key,value){
			  if(value.name.indexOf("from")!=0 && value.name.indexOf("to")!=0)
				  {
				  nodeData[value.name]=value.value; 
				  }
			  
		  });
	}
	
	  this.createVersionControl=function(template)
	  {

		  var currTemplateName=self.currentTemplateName;
		  var templates=self.templates;
		  var itr=0;
		  var matchTemp="";
		  if(currTemplateName.indexOf("_V")==-1)
			  {
			  matchTemp=currTemplateName+"_V";
			  }
		  else
			  matchTemp=currTemplateName.slice(0,currTemplateName.length-2);
		  
		  templates.forEach(function(o,k){
			  if(o.match(matchTemp))
			  {
			  itr=itr+1;
			  }
			  });

			  currTemplateName=matchTemp+"_"+itr;
			  
			  template[0].name=currTemplateName;
			  template[0].path=currTemplateName;
			  template[0].templatePath=currTemplateName;
			  self.updatePathDetails(template[0]);
	  };
	
	  this.addContentToSlot=function(nodeData,content)
	  {
		  if(content)
			  {
			  content.name=content.couponName;
			  content.type="Coupon";
			  }
		  nodeData.couponItems=[];
		  nodeData.associatedCoupon=content.name;
		  
	  }
	  
	return this;
});