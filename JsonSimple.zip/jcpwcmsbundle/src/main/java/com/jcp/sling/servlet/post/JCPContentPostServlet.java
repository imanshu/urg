package com.jcp.sling.servlet.post;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.sling.servlet.JCPSlingServletConstants;


/**
 * A Custom Sling Servlet to convert JSON request to the request attribute
 * 
 */
@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JCPenney - Post Servlet"),
		@Property(name = "service.vendor", value = "JCPenney"),
		@Property(name = "sling.servlet.paths", value = "/content/coupon"),
		@Property(name = "sling.servlet.methods", value = { "POST" }),
		@Property(name = "sling.servlet.extensions", value = { "html", "json" }) })
public class JCPContentPostServlet extends SlingAllMethodsServlet implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log("Inside JCPContentPostServlet.doPost");

		JSONParser parser = new JSONParser();
		String jsonString = "";

		if (JCP_METHOD_POST.equalsIgnoreCase(request.getMethod())) {
			log("JCPContentPostServlet.doPost --> Method type is POST");
			jsonString = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
			if (null != jsonString && !EMPTY_STRING.equals(jsonString)) {
				JSONObject jobj;
				try {
					jobj = (JSONObject) parser.parse(jsonString);
					log("JCPContentPostServlet.doPost --> JSONObj after parsing ---->" + jobj);
					if (null != jobj) {
						convertJSONtoNode(request, jobj);
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}

		log("JCPContentPostServlet.doPost --> JSON from Request Body --> ");
		response.getWriter().write("Put your json here----------->");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}

	/**
	 * @param request
	 * @param jsonObj
	 */
	public void convertJSONtoNode(SlingHttpServletRequest request, JSONObject jsonObj) {
		Session session = null;
		String keyStr = EMPTY_STRING;
		String keyvalue = EMPTY_STRING;
		try {
			if (jsonObj != null) {
				ResourceResolver resourceResolver = request.getResourceResolver();
				log("convertJSONtoNode ----------------> JSON couponName --> " + jsonObj.get(JCP_COUPON_NAME));
				session = resourceResolver.adaptTo(Session.class);
							
				Node node = getNodeToUpdate((String) jsonObj.get(JCP_COUPON_NAME), session, resourceResolver);

				if (null != node) {
					for (Object key : jsonObj.keySet()) {
						keyStr = (String) key;
						keyvalue = (String) jsonObj.get(keyStr);
						node.setProperty(keyStr, keyvalue);
						// Print key and value
						log("key: " + keyStr + " value: " + keyvalue);
					}
				}
				session.save();
			}
		} catch (Exception e) {
			log.equals("Unable to update Node ::::::::::: " + e);
		} finally {
			if (session != null) {
				session.logout();
			}
		}
	}

	/**
	 * This method gets the base node to update the given content
	 * 
	 * @param nodeName
	 * @param session
	 * @param resourceResolver
	 * @return
	 */
	private Node getNodeToUpdate(String nodeName, Session session, ResourceResolver resourceResolver) {
		Node rootNode = null;
		try {
			if (session != null && nodeName != null) {
				Resource resource = resourceResolver.getResource(JCP_COUPON_PATH + nodeName);
				log("resource:#################################################### " + resource);
				if (resource == null) {
					Node couponNode = session.getNode(JCP_COUPON_PATH);
					if (null != couponNode) {
						rootNode = couponNode.addNode(nodeName);
						rootNode.setPrimaryType(JCP_NT_UNSTRUCTURED);
						session.save();
					}					
				} else {
					rootNode = session.getNode(JCP_COUPON_PATH + nodeName);
				}
				log("rootNode:#################################################### " + rootNode);
			}
		} catch (Exception e) {
			log.error("Error creating node :::: ", e);
		}
		return rootNode;
	}
}
