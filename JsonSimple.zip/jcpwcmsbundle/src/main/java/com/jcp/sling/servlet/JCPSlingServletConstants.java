package com.jcp.sling.servlet;

/**
 * The <code>JCPSlingServletConstants</code> interface provides constants
 */
public interface JCPSlingServletConstants {
    
    public static final String JCP_METHOD_POST = "POST";
    public static final String EMPTY_STRING = "";
    public static final String SLASH = "/";
    public static final String HTML_MIME_TYPE = "text/html";
    
    //JSON Key CONSTANTS
    public static final String JCP_COUPON_NAME = "couponName";
    public static final String JCP_NODE_NAME = "name";
    public static final String JCP_ASSET_NAME = "assetName";
    public static final String JCP_TEMPLATE_CONTENT = "templateContent";
    public static final String JCP_PARENT_FOLDER = "parentFolder";
    public static final String JCP_MIME_TYPE = "mimeType";
    public static final String JCP_CONTENT = "jcpcontent";
    
    //JCR CONSTANTS
    public static final String JCP_REFERENCEABLE_MIXIN = "mix:referenceable";
    public static final String JCP_JCR_CONTENT = "jcr:content";
    public static final String JCP_JCR_MIME_TYPE = "jcr:mimeType";
    public static final String JCP_JCR_DATA = "jcr:data";
    public static final String JCP_JCR_LAST_MODIFIED = "jcr:lastModified";
    
    public static final String JCP_NODE_JCR = "jcr:primaryType";
    public static final String JCP_NT_UNSTRUCTURED = "nt:unstructured";
    public static final String JCP_NT_FILE = "nt:file";
    public static final String JCP_NT_RESOURCE = "nt:resource";
    
    //JCP JCR NODE PATH CONSTANTS
    public static final String JCP_NODE_PATH = "path";
    public static final String JCP_COUPON_PATH = "/content/jcp/en/coupon/";
    public static final String JCP_TEMPLATES_PATH = "/content/jcp/en/templates/";
    
    //GENERAL CONSTANTS
    public static final String JCP_ORIGIN_HEADER = "Origin";
    public static final String JCP_ORIGIN = "localhost";
    public static final String JCP_ALL = "*";
    public static final String JCP_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
    public static final String JCP_ALLOW_METHOD = "Access-Control-Allow-Methods";
    public static final String JCP_ALLOWABLE_METHODS = "POST, GET, OPTIONS, PUT, DELETE, HEAD";    

}
