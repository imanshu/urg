package com.jcp.sling.servlet.post;

import java.io.IOException;
import java.util.ListIterator;
import java.util.stream.Collectors;

import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.sling.servlet.JCPSlingServletConstants;

/**
 * A Custom Sling Servlet to convert page template JSON request to object and
 * save as JCR node
 * 
 */
@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JCPenney - Content Template Post Servlet"),
		@Property(name = "service.vendor", value = "JCPenney"),
		@Property(name = "sling.servlet.paths", value = "/content/templates"),
		@Property(name = "sling.servlet.methods", value = { "POST" }),
		@Property(name = "sling.servlet.extensions", value = { "json" }) })
public class JCPContentTemplatePostServlet extends SlingAllMethodsServlet implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log("Inside JCPContentTemplatePostServlet.doPost");
		JSONParser parser = new JSONParser();
		String jsonString = EMPTY_STRING;
		String path = JCP_TEMPLATES_PATH;
		Session jcrSession = null;

		if (JCP_METHOD_POST.equalsIgnoreCase(request.getMethod())) {
			log("JCPContentTemplatePostServlet.doPost --> Method type is POST");

			jsonString = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));

			if (null != jsonString && !EMPTY_STRING.equals(jsonString)) {
				JSONObject jsonObj;
				try {
					jsonObj = (JSONObject) parser.parse(jsonString);

					log("JCPContentTemplatePostServlet.doPost --> JSONObj after parsing ---->" + jsonObj);

					ResourceResolver slingResourceResolver = request.getResourceResolver();

					log("doPost ----------------> JSON Node Name --> " + jsonObj.get(JCP_NODE_NAME));

					jcrSession = slingResourceResolver.adaptTo(Session.class);

					parseRequestJson(request, path, jcrSession, jsonObj, slingResourceResolver);

					jcrSession.save();
				} catch (ParseException e) {
					log("Exception in doPost --> ::::::::::: " + e.getMessage());
					e.printStackTrace();
				} catch (Exception e) {
					log("Generic Exception ::::::::::: " + e.getMessage());
					e.printStackTrace();
				} finally {
					if (jcrSession != null) {
						jcrSession.logout();
					}
				}
			}
		}

		log("JCPContentTemplatePostServlet.doPost --> JSON from Request Body --> ");
		response.getWriter().write("Template saved successfully----------->");
	}

	/**
	 * This method is used to parse the request JSON for identifying the parent node
	 * 
	 * @param request
	 * @param path
	 * @param jcrSession
	 * @param jsonObj
	 * @param slingResourceResolver
	 */
	@SuppressWarnings("rawtypes")
	private void parseRequestJson(SlingHttpServletRequest request, String path, Session jcrSession, JSONObject jsonObj,
			ResourceResolver slingResourceResolver) {
		ListIterator jsonObjListIterator;
		for (Object key : jsonObj.keySet()) {
			String keyStr = (String) key;
			Object keyValue = jsonObj.get(keyStr);

			if (null != keyValue) {
				if (keyValue instanceof JSONObject) {
					log("In parseRequestJson-->Key value is instanceof JSONObject ---------------------------------> ");
					log(keyValue.toString());
					convertJSONtoNode(path, request, (JSONObject) keyValue, jcrSession, slingResourceResolver);
				} else if (keyValue instanceof JSONArray) {
					log("In parseRequestJson-->Key value is instanceof JSONArray ---------------------------------> ");
					log(keyValue.toString());
					jsonObjListIterator = ((JSONArray) keyValue).listIterator();
					while (jsonObjListIterator.hasNext()) {
						convertJSONtoNode(path, request, (JSONObject) jsonObjListIterator.next(), jcrSession,
								slingResourceResolver);
					}
				}
			}
		}
	}

	/**
	 * This method recursively iterates through the JSON object
	 * 
	 * @param path
	 * @param request
	 * @param jsonObj
	 * @param jcrSession
	 * @param slingResourceResolver
	 */
	@SuppressWarnings("rawtypes")
	public void convertJSONtoNode(String path, SlingHttpServletRequest request, JSONObject jsonObj, Session jcrSession,
			ResourceResolver slingResourceResolver) {
		String keyStr = EMPTY_STRING;
		Object keyValueObj = null;
		ListIterator listIterator;
		String name = EMPTY_STRING;
		try {
			if (jsonObj != null) {
				name = (String) jsonObj.get(JCP_NODE_NAME);
				if(null != path && !EMPTY_STRING.equals(path) && !path.endsWith("/")) {
					path = path + "/";					
				}
				Node node = getNodeToUpdate(path, (String) jsonObj.get(JCP_NODE_NAME), jcrSession,
						slingResourceResolver);

				if (null != node) {
					log("In convertJSONtoNode-->Node name in convertJSONtoNode is : " + node.getName());
					for (Object key : jsonObj.keySet()) {
						keyStr = (String) key;
						keyValueObj = jsonObj.get(keyStr);
						if (!JCP_NODE_JCR.equals(keyStr) && null != keyValueObj) {
							//Set the Path value for the Object.
							if (JCP_NODE_PATH.equals(keyStr)) {
								log("Path value is : " + keyValueObj);
								path = JCP_TEMPLATES_PATH + (String) keyValueObj;
							} 
							
							if (keyValueObj instanceof JSONArray) {
								log("In convertJSONtoNode-->Key value is instanceof JSONArray ---------------------------------> ");
								log(keyValueObj.toString());
								listIterator = ((JSONArray) keyValueObj).listIterator();
								while (listIterator.hasNext()) {
									convertJSONtoNode(path, request, (JSONObject) listIterator.next(), jcrSession,
											slingResourceResolver);
								}
							} else if (keyValueObj instanceof JSONObject) {
								log("In convertJSONtoNode-->Key value is instanceof JSONObject ---------------------------------> ");
								log(keyValueObj.toString());
								convertJSONtoNode(path, request, (JSONObject) keyValueObj, jcrSession,
										slingResourceResolver);
							} else {
								log("In convertJSONtoNode-->Key value is ---------------------------------> "
										+ keyValueObj);
								keyValueObj = (String) jsonObj.get(keyStr);
								node.setProperty(keyStr, (String) keyValueObj);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log("Unable to update Node ::::::::::: " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * This method creates the node and update the given content
	 * 
	 * @param path
	 * @param nodeName
	 * @param jcrSession
	 * @param slingResourceResolver
	 * @return
	 */
	private Node getNodeToUpdate(String path, String nodeName, Session jcrSession,
			ResourceResolver slingResourceResolver) {
		Node rootNode = null;
		try {
			if (jcrSession != null && nodeName != null) {
				Resource resource = slingResourceResolver.getResource(path + nodeName);
				log("getNodeToUpdate-->resource: " + resource);
				log("getNodeToUpdate-->path: " + path + "  nodeName: " + nodeName);
				if (resource == null) {
					Node templateNode = jcrSession.getNode(path);
					if (null != templateNode) {
						rootNode = templateNode.addNode(nodeName);
						rootNode.setPrimaryType(JCP_NT_UNSTRUCTURED);
						jcrSession.save();
					}
				} else {
					rootNode = jcrSession.getNode(path + nodeName);
				}
				log("getNodeToUpdate-->rootNode: " + rootNode);
			}
		} catch (Exception e) {
			log("Error creating node :::: " + e.getMessage());
			e.printStackTrace();
		}
		return rootNode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}
}
