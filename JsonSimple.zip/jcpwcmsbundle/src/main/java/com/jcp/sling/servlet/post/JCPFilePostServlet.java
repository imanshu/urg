package com.jcp.sling.servlet.post;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.stream.Collectors;

import javax.jcr.Binary;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.jcr.ValueFactory;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.sling.servlet.JCPSlingServletConstants;

/**
 * A Custom Sling Servlet to store the File content to the JCR and Mongo
 * 
 */
@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JCPenney - Post Servlet for File Content"),
		@Property(name = "service.vendor", value = "JCPenney"),
		@Property(name = "sling.servlet.paths", value = "/content/fragments"),
		@Property(name = "sling.servlet.methods", value = { "POST" }),
		@Property(name = "sling.servlet.extensions", value = { "html", "json" }) })
public class JCPFilePostServlet extends SlingAllMethodsServlet implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log("Inside JCPFilePostServlet.doPost");

		JSONParser parser = new JSONParser();
		String jsonString = "";

		if (JCP_METHOD_POST.equalsIgnoreCase(request.getMethod())) {
			log("JCPFilePostServlet.doPost --> Method type is POST");
			jsonString = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
			if (null != jsonString && !EMPTY_STRING.equals(jsonString)) {
				JSONObject jobj;
				try {
					jobj = (JSONObject) parser.parse(jsonString);
					log("JCPFilePostServlet.doPost --> JSONObj after parsing ---->" + jobj);
					if (null != jobj) {
						convertJSONtoNode(request, jobj);
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}

		log("JCPFilePostServlet.doPost --> JSON from Request Body --> ");
		response.getWriter().write("Put your json here----------->");
	}

	/**
	 * This methods converts the requested JSON to the JCR node
	 * 
	 * @param request
	 * @param jsonObj
	 */
	public void convertJSONtoNode(SlingHttpServletRequest request, JSONObject jsonObj) {
		Session session = null;
		try {
			if (jsonObj != null) {
				ResourceResolver resourceResolver = request.getResourceResolver();
				if (validateJSON(jsonObj)) {
					session = resourceResolver.adaptTo(Session.class);

					createOrUpdateContentNode(jsonObj, session, resourceResolver);

					session.save();
				}
			}
		} catch (Exception e) {
			log.equals("Unable to update Node ::::::::::: " + e);
		} finally {
			if (session != null) {
				session.logout();
			}
		}
	}

	/**
	 * This method creates or update the content node
	 *	 
	 * @param jsonObj
	 * @param session
	 * @param resourceResolver
	 */
	private void createOrUpdateContentNode(JSONObject jsonObj, Session session,
			ResourceResolver resourceResolver) {

		Node assetNode = null;
		Node resourceNode = null;
		String basePath = JCP_TEMPLATES_PATH;
		
		String nodeName = (String)jsonObj.get(JCP_ASSET_NAME);
		String parentFolder = (String)jsonObj.get(JCP_PARENT_FOLDER);
		String mimeType = (String)jsonObj.get(JCP_MIME_TYPE);
		String templateContent = (String)jsonObj.get(JCP_TEMPLATE_CONTENT);
		
		try {
			log("Inside createOrUpdateContentNode");
			if (session != null && nodeName != null) {
				if(null != parentFolder) {
					basePath = basePath + parentFolder + SLASH;
				}
				Resource resource = resourceResolver.getResource(basePath + nodeName);
				log("createOrUpdateContentNode.resource: " + resource);

				if (resource == null) {

					Node baseNode = session.getNode(basePath);

					if (null != baseNode) {
						assetNode = baseNode.addNode(nodeName, JCP_NT_FILE);
						assetNode.setPrimaryType(JCP_NT_FILE);
						assetNode.addMixin(JCP_REFERENCEABLE_MIXIN);
						resourceNode = assetNode.addNode(JCP_JCR_CONTENT, JCP_NT_RESOURCE);
					}
				} else {
					assetNode = session.getNode(basePath + nodeName);
					resourceNode = assetNode.getNode(JCP_JCR_CONTENT);
					log("createOrUpdateContentNode---> Update the existing node" + nodeName + " with content: "
							+ templateContent);
				}

				// Set the binary content or actual string based on the mime
				// type
				if (null != templateContent && templateContent.startsWith(JCP_NODE_PATH + ":")) {
					Binary contentValue = getFileContentAsBinary(templateContent, session);
					resourceNode.setProperty(JCP_JCR_DATA, contentValue);
				} else {
					resourceNode.setProperty(JCP_JCR_DATA, templateContent);
				}

				resourceNode.setProperty(JCP_JCR_MIME_TYPE, mimeType);
				resourceNode.setProperty(JCP_JCR_LAST_MODIFIED, getLastModified());
				log("createOrUpdateContentNode.rootNode: " + assetNode);
			} else {
				log("createOrUpdateContentNode --> Session or Node Name is null...");
			}
		} catch (Exception e) {
			log.error("Error creating node :::: ", e);
		}
	}

	/**
	 * This method gets the file based in the path and converts it to Binary
	 * 
	 * @param content
	 * @param session
	 * @return
	 * @throws FileNotFoundException
	 * @throws UnsupportedRepositoryOperationException
	 * @throws RepositoryException
	 */
	private Binary getFileContentAsBinary(String content, Session session)
			throws FileNotFoundException, UnsupportedRepositoryOperationException, RepositoryException {
		String filePath = content.substring(content.indexOf(JCP_NODE_PATH) + 5);
		File file = new File(filePath);
		FileInputStream is = new FileInputStream(file);
		ValueFactory valueFactory = session.getValueFactory();
		Binary contentValue = valueFactory.createBinary(is);
		return contentValue;
	}

	
	/**
	 * @param jsonObj
	 * @return
	 */
	private boolean validateJSON(JSONObject jsonObj) {

		boolean validJSON = true;

		if (!stringValidate(jsonObj.get(JCP_ASSET_NAME))) {
			log("JCPFilePostServlet.validateJSON: " + JCP_ASSET_NAME + "is null");
			validJSON = false;
		}

		if (!stringValidate(jsonObj.get(JCP_MIME_TYPE))) {
			log("JCPFilePostServlet.validateJSON: " + JCP_MIME_TYPE + "is null");
			validJSON = false;
		}

		if (!stringValidate(jsonObj.get(JCP_TEMPLATE_CONTENT))) {
			log("JCPFilePostServlet.validateJSON: " + JCP_TEMPLATE_CONTENT + "is null");
			validJSON = false;
		}

		if (!stringValidate(jsonObj.get(JCP_PARENT_FOLDER))) {
			log("JCPFilePostServlet.validateJSON: " + JCP_PARENT_FOLDER + "is null");
			validJSON = false;
		}

		return validJSON;
	}

	/**
	 * This method validates the empty & null check for a given string
	 * 
	 * @param stringContent
	 * @return
	 */
	private boolean stringValidate(Object stringContent) {
		boolean validString = false;
		if (null != stringContent && !EMPTY_STRING.equals(stringContent.toString())) {
			validString = true;
		}
		return validString;
	}

	/**
	 * This methods returns the current date-time as last modified date
	 * 
	 * @return
	 */
	private Calendar getLastModified() {
		Calendar lastModified = Calendar.getInstance();
		lastModified.setTimeInMillis(lastModified.getTimeInMillis());
		log("getLastModified---> Last Modified Time: " + lastModified);
		return lastModified;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}

}
