package com.jcp.assembler;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ListIterator;
import java.util.stream.Collectors;

import javax.jcr.Node;
import javax.jcr.Session;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.assembler.servlet.JCPSlingServletConstants;

/**
 * @author karthikeyangirijanandan
 * 
 *         <code>JCPContentAssembler</code> class is used to parse the page
 *         template JSON and get the HTML content base don the template path of
 *         each nodes
 *
 */
public class JCPContentAssembler implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * This method is used to process the given JSON content and return the
	 * htmlContent
	 * 
	 * @param session
	 * @param jobj
	 * @return
	 */
	public StringBuilder processContent(Session session, JSONObject jobj) {
		StringBuilder htmlContent = new StringBuilder();

		processJson(session, jobj, htmlContent);

		// append the final closing div in this method
		htmlContent.append(CLOSING_DIV);

		log("FINAL HTML CONTENT" + htmlContent.toString());

		return htmlContent;

	}

	/**
	 * This method is used to recursively iterate on the JSON and retrieve the
	 * template content based on the template path
	 * 
	 * @param session
	 * @param jsonObj
	 * @param htmlContent
	 */
	@SuppressWarnings("rawtypes")
	private void processJson(Session session, JSONObject jsonObj, StringBuilder htmlContent) {
		ListIterator jsonObjListIterator;

		Object keyValue = jsonObj.get(CHILDREN_NODE);

		if (keyValue != null && keyValue instanceof JSONArray) {
			jsonObjListIterator = ((JSONArray) keyValue).listIterator();
			htmlContent.append(getTemplateContent(session, jsonObj));

			while (jsonObjListIterator.hasNext()) {
				processJson(session, (JSONObject) jsonObjListIterator.next(), htmlContent);
				htmlContent.append(CLOSING_DIV);
			}
		} else {
			htmlContent.append(getTemplateContent(session, jsonObj));
		}

	}

	/**
	 * This method is used to retrieve the template content based on the node
	 * 
	 * @param session
	 * @param jsonObj
	 * @return
	 */
	private Object getTemplateContent(Session session, JSONObject jsonObj) {
		String contentTemplatePath = (String) jsonObj.get(TEMPLATE_PATH);
		String templateContentStr = null, serviceLinkStr = null;
		

		if (null != contentTemplatePath && !EMPTY_STRING.equals(contentTemplatePath)) {
			if(null != jsonObj.get(SERVICE_LINK)) {
				serviceLinkStr = jsonObj.get(SERVICE_LINK).toString();
			}
			
			log("Service URL for contentTemplatePath: " + serviceLinkStr);
			templateContentStr = getFileContentFromNode(jsonObj, session, contentTemplatePath,
					serviceLinkStr);
		}
		return templateContentStr;
	}

	/**
	 * This method is used to get the File content from the node
	 * 
	 * @param session
	 * @param contentTemplatePath
	 * @return
	 */
	private String getFileContentFromNode(JSONObject jsonObj, Session session, String contentTemplatePath, String serviceLink) {
		String templateContentStr = null;
		try {
			Node templateNode = session.getNode(contentTemplatePath);
			if (null != templateNode) {
				JCPContentRuleEngine contentRuleEngine = new JCPContentRuleEngine();
				
				//Check the content start date and end date
				if(contentRuleEngine.isContentValidForDate(jsonObj)) {
					// Get Content Node
					Node jcrContent = templateNode.getNode(JCR_CONTENT);

					if (null != jcrContent) {
						// Get actual file content as JCR data stream
						InputStream contentStream = jcrContent.getProperty(JCR_DATA).getBinary().getStream();
						// convert data stream to string
						templateContentStr = new BufferedReader(new InputStreamReader(contentStream)).lines()
								.collect(Collectors.joining(HTML_NEXT_LINE));

						templateContentStr = contentRuleEngine.validateTemplateContent(templateContentStr, serviceLink);
						log("Template Content String ingetFileContentFromNode : " + templateContentStr);
					}
				}
			}
		} catch (Exception ex) {
			log.error("Exception while fetting file Node: " + ex.getMessage());
		}
		return templateContentStr;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}
}
