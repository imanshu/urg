package com.jcp.assembler.servlet;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.assembler.JCPContentAssembler;

/**
 * @author karthikeyangirijanandan
 * 
 *<code>JCPContentRetrieverServlet.</code> is a Custom Sling Servlet to return the complete HTML based on the page template JSON
 *
 */
@Component(immediate = true, metatype = true)
@Service(Servlet.class)
@Properties({ @Property(name = "service.description", value = "JCPenney - Get Servlet"),
		@Property(name = "service.vendor", value = "JCPenney"),
		@Property(name = "sling.servlet.paths", value = "/jcpcontent/getContent"),
		@Property(name = "sling.servlet.methods", value = { "GET, POST" }),
		@Property(name = "sling.servlet.extensions", value = { "html", "json" }) })
public class JCPContentRetrieverServlet extends SlingAllMethodsServlet implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		log("Inside JCPContentRetrieverServlet..doPost");

		JSONParser parser = new JSONParser();
		String jsonString = "";
		Session session = null;
		StringBuilder finalContent = new StringBuilder();
		
		if (JCP_METHOD_POST.equalsIgnoreCase(request.getMethod())) {
			log("JCPContentRetrieverServlet..doPost --> Method type is POST");
			jsonString = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));
			if (null != jsonString && !EMPTY_STRING.equals(jsonString)) {
				JSONObject jobj;
				try {
					jobj = (JSONObject) parser.parse(jsonString);
					log("JCPContentRetrieverServlet..doPost --> JSONObj after parsing ---->" + jobj);
					if (null != jobj) {
						session = request.getResourceResolver().adaptTo(Session.class);
						JCPContentAssembler contentAssembler = new JCPContentAssembler();
						finalContent = contentAssembler.processContent(session, jobj);
						log("FINAL HTML CONTENT IN SERRVLET" + finalContent.toString());
					}
				} catch (ParseException e) {
					e.printStackTrace();
				} catch (Exception ex) {
					log.error("Exception while fetting file Node: " + ex.getMessage() );
				} finally {
					if (session != null) {
						session.logout();
					}
				}
			}
		}

		log("JCPContentRetrieverServlet..doPost --> JSON from Request Body --> ");
		response.getWriter().write(finalContent.toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}
	
}
