package com.jcp.assembler.servlet;

/**
 * @author karthikeyangirijanandan
 * 
 * The <code>JCPSlingServletConstants</code> interface provides constants
 */
public interface JCPSlingServletConstants {
    
    public static final String JCP_METHOD_GET = "GET";
    public static final String JCP_METHOD_POST = "POST";
    public static final String EMPTY_STRING = "";
    public static final String SLASH = "/";
    public static final String SPACE = " ";
    public static final String TEMPLATE_PATH = "templatePath";
    public static final String SERVICE_LINK = "serviceLink";
    public static final String SERVICE_LINK_ATTR = "service-link";
    public static final String DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
    public static final String CONTENT_START_DATE = "contentItemStartDate";
    public static final String CONTENT_END_DATE = "contentItemEndDate";
    
    //HTML CONSTANTS
    public static final String CLOSING_DIV = "</div>";
    public static final String CHILDREN_NODE = "__children__";
    public static final String HTML_DIV = "<div>";
    public static final String HTML_DIV_NO_CLOSURE = "<div";
    public static final String HTML_NEXT_LINE = "\n";
   // public static final String SERVICE_DATA_URL_ATTR = "serviceDataURL";
    public static final String HTML_BODY_TAG = "body";
    
    //JCR CONSTANTS
    public static final String JCR_CONTENT ="jcr:content";
    public static final String JCR_DATA ="jcr:data";
}
