package com.jcp.assembler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.assembler.servlet.JCPSlingServletConstants;

/**
 * @author karthikeyangirijanandan
 * 
 *         <code>JCPContentRuleEngine</code> class is used to do the content
 *         based rule validations.
 *
 */
public class JCPContentRuleEngine implements JCPSlingServletConstants {

	private final Logger log = LoggerFactory.getLogger(getClass());

	/**
	 * This method is used to check the contentItem's date validity
	 * 
	 * @param templateNode
	 * @return isContentValid
	 * @throws ValueFormatException
	 * @throws RepositoryException
	 * @throws PathNotFoundException
	 * @throws ParseException
	 */
	public boolean isContentValidForDate(JSONObject jsonObj)
			throws ValueFormatException, RepositoryException, PathNotFoundException, ParseException {

		boolean isContentValid = false;
		Date contentItemStartDate = null, contentItemEndDate = null;
		String contentItemStartDateStr = (String) jsonObj.get(CONTENT_START_DATE);
		String contentItemEndDateStr = (String)jsonObj.get(CONTENT_END_DATE);

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
		if (null != contentItemStartDateStr && !EMPTY_STRING.equals(contentItemStartDateStr.trim())) {
			contentItemStartDate = formatter.parse(contentItemStartDateStr);
		}

		if (null != contentItemEndDateStr && !EMPTY_STRING.equals(contentItemEndDateStr.trim())) {
			contentItemEndDate = formatter.parse(contentItemEndDateStr);
		}

		Date currentDate = new Date();

		if (contentItemStartDate.before(currentDate) && contentItemEndDate.after(currentDate)) {
			isContentValid = true;
		}
		log("isContentValidForDate--> Content Validity: " + isContentValid);
		return isContentValid;
	}

	/**
	 * This method does following operations.
	 * 
	 * 1. Append div tag on the beginning of the content if the content doesn't
	 * starts with the div
	 * 
	 * 2. Remove the closure div of the content if the content already starts
	 * with the div
	 * 
	 * The above operations or done to manipulate the DOM so as to fit div
	 * within div of the layout structure
	 * 
	 * @param templateContentStr
	 * @return
	 */
	public String validateTemplateContent(String templateContentStr, String serviceDataURL) {
		if (null != templateContentStr) {
			templateContentStr = templateContentStr.trim();
			log("Template Content String Before: " + templateContentStr);

			if (null != serviceDataURL && !EMPTY_STRING.equals(serviceDataURL)) {
				templateContentStr = addServiceDataURL(templateContentStr, serviceDataURL);
			} else {
				if(!templateContentStr.startsWith(HTML_DIV_NO_CLOSURE)) {
					templateContentStr = HTML_DIV + templateContentStr;
				}
				
			}

			templateContentStr = templateContentStr.substring(0, templateContentStr.lastIndexOf(CLOSING_DIV));

			log("Template Content String After: " + templateContentStr);
		}
		return templateContentStr;
	}

	/**
	 * This method is used to check if service Data URL is not empty then append
	 * the new attribute to DIV tag with the URL to be called. This is done to
	 * make the appropriate service call for this DIV from the front end
	 * framework
	 * 
	 * @param templateContentStr
	 * @param serviceDataURL
	 * @return
	 */
	private String addServiceDataURL(String templateContentStr, String serviceDataURL) {
		Document doc = Jsoup.parse(templateContentStr);
		Element bodyElem = doc.select(HTML_BODY_TAG).get(0);

		if (null != bodyElem && bodyElem.html().startsWith(HTML_DIV_NO_CLOSURE)) {
			bodyElem.child(0).attr(SERVICE_LINK_ATTR, serviceDataURL);
		} else {
			bodyElem.child(0).wrap(
					HTML_DIV_NO_CLOSURE + SPACE + SERVICE_LINK_ATTR + "='" + serviceDataURL + "'>" + CLOSING_DIV);
		}
		return bodyElem.html();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#log(java.lang.String)
	 */
	public void log(String msg) {
		log.info(msg);
	}
}
