package com.jcp.sling.servlet.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcp.sling.servlet.JCPSlingServletConstants;

/** 
 * @author karthikeyangirijanandan
 * 
 * Filter for all Origin 
 * 
 **/
@Component(immediate = true, metatype = false)
@Service(value = javax.servlet.Filter.class)
@Properties({ @Property(name = "service.description", value = "Allow All Origin"),
		@Property(name = "service.vendor", value = "JCPenney"),
		@Property(name = "sling.filter.scope", value = "request") })
public class JCPCrossOriginFilter implements Filter, JCPSlingServletConstants {
	
	private final Logger log = LoggerFactory.getLogger(getClass());

	 /* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
			throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse response = (HttpServletResponse) res;
		String origin = request.getHeader(JCP_ORIGIN_HEADER);
		
		log.info("IN JCPCrossOriginFilter origin value: " + origin + " method type --> " + request.getMethod());
		
		if (origin != null && origin.contains(JCP_ORIGIN)) {
			log.info("In JCPCrossOriginFilter localhost origin");
				response.addHeader(JCP_ALLOW_ORIGIN, JCP_ALL);		
		        response.addHeader(JCP_ALLOW_METHOD, JCP_ALLOWABLE_METHODS);	
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}
}