jcpStorefrontApp.controller("bodySectionCtrl",function($scope,ContentService,$state,$timeout){
	
 

	
	$scope.dataShow=false;
	$scope.pageLoaded=false;
	$scope.data="Shopwide";
	
	$scope.data={
		rowHeading:'Row Layout'
		
};
	
	$("#container").append("<script id='pagetemplate1.html' type='text/ng-template'><div class='row headerSec'><h1>Header Comes Here</h1></div><div id='page_wrapper' class='bodySection' ng-controller='bodySectionCtrl'><div class='row columnLayout'><div class='row RowLayout'><h3 class='RowHeading'>{{data.rowHeading}}</h3></div> </div></div></script>");
	$scope.data.template="pagetemplate.html";
	$scope.initialize=function(scope){
		scope.pageLoaded=true;
		
		
		window.selfie=scope;
/*		ContentService.getTemplateData('templates', "JcpCouponPageTemplate").then(
				function(response) {
					$scope.data=response.data;console.log(response);
				ContentService.getAssembledData(response.data).then(function(response){
						console.log(response);
						
						
						
						$scope.response="<div class='row headerSec'><h1>Header Comes Here</h1></div><div id='page_wrapper' class='bodySection' ng-controller='bodySectionCtrl'><div class='row columnLayout'><div class='row RowLayout'><h3 class='RowHeading'>{{data.rowHeading}}</h3></div> </div></div>";
						
						//$("#container").append("<div  id='wrapper' ng-include='pagetemplate.html'></div>");
						//$state.go("pageT", {});
						$scope.dataShow=true;
						//return $scope.response;
					});
					
					
				});
		*/
		
	};
	
	$timeout($scope.initialize($scope),200);
		
	

})
.directive('pageTemplate', ['$compile', '$http', '$templateCache', function($compile, $http, $templateCache) {

	        var getTemplate = function() {
	        	var templateName="";
	        	if(window.location.href.split("?")[1] == undefined || window.location.href.split("?")[1] == "")
	        		{
	        		templateName="KarthikPageTemplate";
	        		}
	        	else
	        		{
	        		templateName=window.location.href.split("?")[1];
	        		}
	            var getDetails= $http.get("http://localhost:8080/content/jcp/en/templates/"+templateName+".harray.infinity.json");
	           

	            return getDetails;

	        };
	        var getPageTemp = function(data){
	        	var templateLoader = $http.post("http://localhost:8080/jcpcontent/getContent/",data); 
	        	return templateLoader;
	        };

	        var linker = function(scope, element, attrs) {

	            var loaderDet = getTemplate();
	            

	            var promise = loaderDet.success(function(html) {
	            	var datas=html;
	            	scope.data=scope.$parent.data;
	            	var loader=getPageTemp(datas);
	            	loader.success(function(html){
	            		console.log(html);
	            		element.html(html);
	            	}).then(function(response){
	            		 element.replaceWith($compile(element.html())(scope));
	            	})
	                
	            }).then(function (response) {
	               
	            });
	        };
	        
	        var templateCtrl=function(scope,attrs)
	        {
	        	scope.initialize=function(){
	        		console.log("init");
	        	};
	        };

	        return {
	            restrict: 'E',
	            scope: {
	                post:'='
	            },
	            link: linker,
	            transclude:true
	        };
	    }])
	    .directive('serviceLink', ['$compile', '$http', '$templateCache', function($compile, $http, $templateCache) {

	        var getContent = function(link) {
	            var getDetails= $http.get(link);
	           

	            return getDetails;

	        };
	        
	        var getContentTemplate = function(link){
	            var getDetails= $http.get(link);
	            return getDetails;
	        };
	        var linker = function(scope, element, attrs) {
	        	console.log("I am in");
	            var loaderDet = getContent(attrs.serviceLink);
	            scope.data={};
	            scope.data.couponname=attrs.couponAsset;
	            var promise = loaderDet.success(function(data) {
	            	scope.data=data;
	            	var contentDataTemplate=getContentTemplate('http://localhost:8080/content/jcp/en/templates/fragments/CouponContentDataHTML');
	            	contentDataTemplate.success(function(data){
	            		if(data!=null)
	            		element.html(data);
	            	}).then(function(response){
	            		element.replaceWith($compile(element.html())(scope));
	            	});
	            	//element.html('<div id="1" class="couponItem_container col-lg-4 Content"><div class="row CntFields couponItem_location">{{data.Channel}}</div><ul class="row CntFields couponItem_offers"><li class=""><h4>{{data.offer1Name}}</h4><span>{{data.offer1Description}}</span></li><li class=""><h4>{{data.offer2Name}}</h4></li></ul><div class="row CntFields couponItem_valid">{{data.validName}}</div><div class="row CntFields couponItem_code">Code:<strong>{{data.codeValue}}</strong></div><div class="row CntFields couponItem_listDetails"><div class="coupon_btn"><div class="coupon-left"><a href="#" class="btn btn-secondary">Apply</a></div><div class="coupon-right"><a href="#" class="btn btn-secondary">Print</a></div></div></div></div>');
	            	}).then(function (response) {
	            	
	            });
	        }

	        return {
	            restrict: 'A',
	            scope: {
	                couponname:'='
	            },
	            link: linker,
	            transclude:true
	        };
	    }]);
/*.directive('checkIt', function($http) {
	  return {
		  scope:{},  
		  restrict:'E',
		    
template: function(elem,attr)
		  {
			var i=1,data='';
		return function main(){
				
				$http.post("http://localhost:8080/jcpcontent/getContent/","Shopwide")
			.then(
					function(resp){
						
						data="Hi Am Here";
						if(i==1)
							{
							i=i+1;
							main();
							}
				
						});
				
			
			return "Hi am here";
		  }
		  }
		  }*/

