/*Node Service*/
jcpStorefrontApp.service('NodeService',function($timeout,$http){
	var self=this;
	this.treeValue={};
	this.currentModel={};
	this.templates=[];
	this.currentTemplateName="";
	this.coupons=[];
	this.templateData="";
	
	

	  
	return this;
});