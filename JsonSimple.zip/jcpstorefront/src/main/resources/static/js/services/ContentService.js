/*Node Service*/
jcpStorefrontApp.factory('ContentService',function($timeout,$http){
	var responseData={};
	 var getData=function(type, name){
		
        
        	var promise = $http.get("http://localhost:8080/content/jcp/en/" + type + "/" + name + ".json")
            .then(function(response) {
            	console.log(response);
            	responseData=response;
            	return responseData;
            });
        	return promise;
        
        
	};
	
	 var getTemplateData=function(type, templateName){	        
     	var promise = $http.get("http://localhost:8080/content/jcp/en/templates/JcpCouponPageTemplate.harray.infinity.json")
         .then(function(response) {
         	console.log(response);
         	responseData=response;
         	return responseData;
         });
     	return promise;
     
     
	};
	
	 var deleteTemplateData=function(type, templatePath){	        
	     	var promise = $http.delete("http://localhost:8080"+templatePath)
	         .then(function(response) {
	         	console.log(response);
	         	responseData=response;
	         	return responseData;
	         });
	     	return promise;
	     
	     
		};
		
	var saveData=function(type,jsonData){
		var slingPath="http://localhost:8080/content/" + type;
		
        /*Sending the data to the Server*/
		var promise = $http({
        	method: "POST",
            url: slingPath,
            data: jsonData
        }).
        then(function(response) {
        	console.log(response);
        	responseData=response;
        	return responseData;
        }, function(response) {
        	responseData=response;
        	return responseData;
            
        });
		return promise;
		
	};
	
	var saveFragment=function(jsonData){
		var slingPath="http://localhost:8080/content/jcp/en/fragments";
		
        /*Sending the data to the Server*/
		var promise = $http({
        	method: "POST",
            url: slingPath,
            data: jsonData
        }).
        then(function(response) {
        	console.log(response);
        	responseData=response;
        	return responseData;
        }, function(response) {
        	responseData=response;
        	return responseData;
            
        });
		return promise;
		
	};
	
	var getCollection=function(type){
		
		var promise = $http.get("http://localhost:8080/content/jcp/en/"+type+".infinity.json")
        .then(function(response) {
            responseData = response;
            return responseData;
        });
		return promise;
        
	};
	var getAssembledData=function(data)
	{
		var promise = $http.post("http://localhost:8080/jcpcontent/getContent/",data)
        .then(function(response) {
            responseData = response;
            return responseData;
        });
		return promise;
	};
	return {
		getData:getData,
		saveData:saveData,
		getTemplateData:getTemplateData,
		getCollection:getCollection,
		deleteTemplateData:deleteTemplateData,
		getAssembledData:getAssembledData
	};
});