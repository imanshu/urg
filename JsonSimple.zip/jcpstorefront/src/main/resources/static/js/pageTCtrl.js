jcpStorefrontApp.controller('pageTCtrl',function($scope){
	$scope.pageTemplate="pagetemplate1.html";
	
	
}); 