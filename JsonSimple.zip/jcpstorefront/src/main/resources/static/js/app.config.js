jcpStorefrontApp.config(function($stateProvider, $urlRouterProvider, $httpProvider) {

/*header configurations for cross-domain requests*/
    $httpProvider.defaults.headers.common = {};
    $httpProvider.defaults.headers.post = {};
    $httpProvider.defaults.headers.put = {};
    $httpProvider.defaults.headers.patch = {};



    /*url mappings using angular-ui for later enchancements*/
    $stateProvider
        .state('pageT', {
            url: "/pageT",
            templateUrl: "partials/pageT.html",
            controller:"pageTCtrl"
        });
    
});

