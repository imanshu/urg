var jcpStorefrontApp=angular.module('jcpStorefrontApp',['ui.router']);
