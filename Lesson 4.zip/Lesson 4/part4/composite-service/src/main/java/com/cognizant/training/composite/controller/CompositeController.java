package com.cognizant.training.composite.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.training.composite.domain.Product;
import com.cognizant.training.composite.domain.topic;
import com.cognizant.training.composite.service.ProductService;
import com.cognizant.training.composite.service.topicService;

@Controller
@Component
public class CompositeController {
	private static Logger logger = LoggerFactory.getLogger(CompositeController.class);
	
	@Autowired
	ProductService service;
	
	@Autowired
	@Qualifier("topicService")
	topicService topicservice;

	@RequestMapping(method = RequestMethod.GET, path = "/product/{id}", produces = "application/json; charset=UTF-8")
	public @ResponseBody topic getTopic(@PathVariable("id") String id) {
		logger.info("incoming product Id is " + id);
		//return service.getById(Long.parseLong(id));
		int Id = Integer.valueOf(id);
		Product product = new Product();
		product = service.getById(Long.parseLong(id));
		return topicservice.getTopicById(Id);
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "/mix/{id}", produces = "application/json; charset=UTF-8")
	public @ResponseBody Map<topic,Product> getTopicAndProduct(@PathVariable("id") String id) {
		logger.info("incoming product Id is " + id);
		//return service.getById(Long.parseLong(id));
		Map<topic,Product> list = new HashMap<topic,Product>();
		int Id = Integer.valueOf(id);
		Product product = new Product();
		product = service.getById(Long.parseLong(id));
		topic topic = new topic();
		topic = topicservice.getTopicById(Id);
		list.put(topic, product);
		return list;
	}

	@RequestMapping(method = RequestMethod.POST, path = "/saveproduct", consumes = "application/json; charset=UTF-8")
	public @ResponseBody boolean saveProduct(@RequestBody Product product) {
		logger.info("incoming product " + product);
		if (product != null) {
			logger.info("product id is " + product.getId());
			logger.info("product name is " + product.getName());
		}
		return service.saveProduct(product);
	}
}