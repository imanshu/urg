package com.cognizant.training.composite.service;

import com.cognizant.training.composite.domain.Product;
import com.cognizant.training.composite.domain.topic;

public interface ProductService {
	public Product getById(Long id);	
	public boolean saveProduct(Product product);
	public topic getTopicById(int id);
	public boolean saveTopic(topic topic);
}
