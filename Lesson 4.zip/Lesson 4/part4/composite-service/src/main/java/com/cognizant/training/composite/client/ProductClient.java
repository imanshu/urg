package com.cognizant.training.composite.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.training.composite.domain.Product;

import feign.Headers;

@FeignClient(name = "product-service", fallback = ProductFallback.class)
public interface ProductClient {
	
	@RequestMapping(method = RequestMethod.GET, value = "/product/{id}")
	@Headers("Content-Type: application/json")
	Product getProduct(@PathVariable(value = "id") long id);
	
	@RequestMapping(method = RequestMethod.POST, value = "/saveproduct")
	boolean saveProduct(@RequestBody Product product);

}
