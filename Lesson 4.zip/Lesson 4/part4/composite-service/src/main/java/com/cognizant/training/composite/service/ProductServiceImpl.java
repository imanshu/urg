package com.cognizant.training.composite.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.training.composite.client.ProductClient;
import com.cognizant.training.composite.client.TopicClient;
import com.cognizant.training.composite.domain.Product;
import com.cognizant.training.composite.domain.topic;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {
	private static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	@Autowired
	ProductClient productClient;
	
	@Autowired
	TopicClient topicClient;
	
	public Map<topic,Product> list = new HashMap<topic,Product>();

	@Override	
	public Product getById(Long id) {
		logger.info("calling the service with id " + id);
		return productClient.getProduct(id);
	}

	@Override
	public boolean saveProduct(Product product) {		
	    logger.info("calling the service to save with id " + product.getId()); 
		return productClient.saveProduct(product);
	}	
	
	@Override
	public topic getTopicById(int id) {
		logger.info("calling the service with id " + id);
		return topicClient.getTopicById(id);
	}

	@Override
	public boolean saveTopic(topic topic) {		
	    logger.info("calling the service to save with id " + topic.getId()); 
		return topicClient.saveTopic(topic);
	}
}
