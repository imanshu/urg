package com.cognizant.training.composite.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cognizant.training.composite.domain.Product;
import com.cognizant.training.composite.domain.topic;

// This is needed otherwise the class will not be available to be loaded during the startup
@Component
public class TopicFallback implements TopicClient {
	private static Logger logger = LoggerFactory.getLogger(TopicFallback.class);

	@Override
	public topic getTopicById(int id) {
		logger.error("invoking the fallback");
		topic topic = new topic();
		topic.setId(id);
		topic.setName("default course");
		topic.setDescription("no des.");
		return topic;
	}

	@Override
	public boolean saveTopic(topic topic) {
		logger.error("topic can't be saved :");
		return false;
	}
	
	


}
