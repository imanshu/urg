package com.cognizant.training.composite.service;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cognizant.training.composite.client.TopicClient;
import com.cognizant.training.composite.domain.topic;


@Service(value = "topicService")
@Component
public class topicService {
	
	private static Logger logger = (Logger) LoggerFactory.getLogger(topicService.class);
	
	@Autowired
	TopicClient topicclient;

	public topic getTopicById(int id) {
		logger.info("calling the service with id " + id);
		return topicclient.getTopicById(id);
	}

	public boolean saveTopic(topic topic) {		
	    logger.info("calling the service to save with id " + topic.getId()); 
		return topicclient.saveTopic(topic);
	}
	
}
