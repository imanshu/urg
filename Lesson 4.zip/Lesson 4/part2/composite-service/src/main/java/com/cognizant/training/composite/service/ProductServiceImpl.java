package com.cognizant.training.composite.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cognizant.training.composite.domain.Product;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	RestTemplate restTemplate;

	@Override
	public Product getById(Long id) {
		return restTemplate.getForObject("http://product-service/product/" + id, Product.class);
	}

	@Override
	public boolean saveProduct(Product product) {
		String url = "http://product-service/saveproduct";
		JSONObject request = new JSONObject();
		request.put("id", product.getId());
		request.put("name", product.getName());
		// set headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);

		ResponseEntity<Boolean> response = restTemplate.exchange(url, HttpMethod.POST, entity, Boolean.class);
		return response.getBody();
	}

}
