package com.cognizant.training.composite.service;

import com.cognizant.training.composite.domain.Product;

public interface ProductService {
	public Product getById(Long id);	
	public boolean saveProduct(Product product);
}
