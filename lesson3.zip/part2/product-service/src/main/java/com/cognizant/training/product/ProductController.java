package com.cognizant.training.product;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	       
	        @RequestMapping("/data")
			public String returnDataJson(HttpServletRequest request) {
				return "some data";
			}
}
