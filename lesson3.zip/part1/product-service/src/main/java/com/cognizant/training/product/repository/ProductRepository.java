package com.cognizant.training.product.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.training.product.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
