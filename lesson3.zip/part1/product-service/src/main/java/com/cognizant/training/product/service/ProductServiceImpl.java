package com.cognizant.training.product.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.training.product.domain.Product;
import com.cognizant.training.product.repository.ProductRepository;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {

	private static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

	@Autowired
	ProductRepository repository;

	@Override
	public Product getById(Long id) {
		Product product = new Product();
		if (id != null) {
			logger.info("getting the product with id " + id);
			product = repository.findOne(id);			
		} else {
			logger.error("Product cannot be retrived for null id");
		}
		return product;
	}

	@Override
	public boolean saveProduct(Product product) {
		boolean result = false;
		if (product != null) {
			repository.save(product);
			result = true;
		} else {
			logger.error("Null product cannot be saved");
		}
		return result;
	}

}
